import os

import pandas as pd

from numeric.save_rr import extract_r_indexes, save_csv

folder_path = "ecg"

files = [f for f in os.listdir(folder_path) if os.path.isfile(os.path.join(folder_path, f))]


for path in files:
    print(path)
    data = pd.read_csv(folder_path+"/"+path)
    r = extract_r_indexes(data)
    path = path.replace("ECG", "R")
    save_csv(r, "r/"+path)
